# MEAC_Website

### Don't forget to unzip and rezip the images folder
[MEAC_Website\MEAC_Website\MEAC_Website\static\images.zip](https://github.com/ehansen31/MEAC_Website/blob/Working/MEAC_Website/MEAC_Website/static/images.zip)


<br>
<br>

