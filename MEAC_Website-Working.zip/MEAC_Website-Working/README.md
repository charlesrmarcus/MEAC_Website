# MEAC_Website

### Don't forget to unzip and rezip the images folder
[MEAC_Website\MEAC_Website\MEAC_Website\static\images.zip](https://github.com/ehansen31/MEAC_Website/blob/Working/MEAC_Website/MEAC_Website/static/images.zip)


<br>
<br>

![got tha coffee](http://25.media.tumblr.com/b372a069bb880375d1b32b63a966e38b/tumblr_mukmk4rXzy1s80ppfo1_250.gif)